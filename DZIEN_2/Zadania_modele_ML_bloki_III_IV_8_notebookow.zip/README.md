# Zadania kursowe — modele ML, bloki III i IV

Osiem **osobnych notebooków do samodzielnego uzupełnienia**. W każdym są gotowe importy i dane, cztery (SVM: trzy) zestawy poleceń, miejsca na kod i pytania interpretacyjne. Rozwiązania nie są dołączone.

| Plik | Temat | Typ |
| --- | --- | --- |
| 01_ridge_regresja.ipynb | Ridge, regularyzacja, CV | regresja |
| 02_pca_redukcja_wymiarow.ipynb | PCA, wariancja, wizualizacja | redukcja wymiarów |
| 03_regresja_logistyczna.ipynb | próg, macierz pomyłek, precision/recall | klasyfikacja binarna |
| 04_gradient_boosting.ipynb | tempo uczenia, liczba drzew, CV | klasyfikacja wieloklasowa |
| 05_random_forest.ipynb | las vs drzewo, ważność cech | klasyfikacja wieloklasowa |
| 06_kmeans_klasteryzacja.ipynb | grupowanie, silhouette, ARI | uczenie bez nadzoru |
| 07_svm_klasyfikacja.ipynb | jądra, C, Pipeline | klasyfikacja wieloklasowa |
| 08_mlp_siec_neuronowa.ipynb | architektura sieci, loss curve | sieć neuronowa |

## Uruchomienie

1. Rozpakuj ZIP, otwórz pliki `.ipynb` w JupyterLab lub Google Colab.
2. Środowisko: Python 3, `numpy`, `pandas`, `matplotlib`, `scikit-learn`. W Colab pakiety są zwykle dostępne; lokalnie: `pip install numpy pandas matplotlib scikit-learn jupyterlab`.
3. Uruchom pierwszą komórkę kodu. W kolejnych usuń `raise NotImplementedError(...)` i wpisz własne rozwiązanie. Na końcu dopisz odpowiedzi do pytań.
4. Dane są wbudowane w scikit-learn. Nie trzeba pobierać plików CSV ani korzystać z internetu.

Zalecana kolejność: 01 → 03 → 05 → 04 → 02 → 06 → 07 → 08. Każdy notebook działa niezależnie.

**Uwaga metodyczna:** Porównania hiperparametrów wykonuj na treningu z CV lub oddzielnej walidacji. Test wykorzystaj do końcowej oceny.
